Module containing python wrappers for smart contracts written in solidity.


Distributed as source distribution: ```python setup.py sdist```

Distributed as binary distribution: ```python setup.py bdist_wheel```

To pip install source distribution or add path to file in requirements.txt:
``` cmd
    pip install pypayment-0.1.0.tar.gz
```

To pip install binary distribution or add path to file in requirements.txt:
``` cmd
    pip install pypayment-0.1.0-py3-none-any.whl
```
