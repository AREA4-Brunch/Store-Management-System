from abc import ABC


class Payment(ABC):
    pass
